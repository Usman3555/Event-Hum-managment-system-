# gui_admin.py

import tkinter as tk
from tkinter import simpledialog, messagebox
from hall import halls, load_halls, save_halls, add_hall as add, edit_hall as edit, delete_hall as delete

def refresh_listbox(listbox):
    listbox.delete(0, tk.END)
    for hall in halls:
        listbox.insert(tk.END, f"{hall.name} | {hall.location} | Rs.{hall.price_per_head}/head")

def add_hall_gui():
    name = simpledialog.askstring("Add Hall", "Enter Hall Name:")
    location = simpledialog.askstring("Add Hall", "Enter Location:")
    price = simpledialog.askinteger("Add Hall", "Enter Price per Head:")

    if name and location and price:
        add(name, location, price)
        save_halls()  # ✅ Save after add
        refresh_listbox(hall_listbox)

def edit_hall_gui():
    selected = hall_listbox.curselection()
    if not selected:
        messagebox.showwarning("Edit Hall", "Please select a hall to edit.")
        return

    index = selected[0]
    new_location = simpledialog.askstring("Edit Hall", "Enter New Location:")
    new_price = simpledialog.askinteger("Edit Hall", "Enter New Price per Head:")

    if new_location and new_price:
        edit(index, new_location, new_price)
        save_halls()  # ✅ Save after edit
        refresh_listbox(hall_listbox)

def delete_hall_gui():
    selected = hall_listbox.curselection()
    if not selected:
        messagebox.showwarning("Delete Hall", "Please select a hall to delete.")
        return

    index = selected[0]
    confirm = messagebox.askyesno("Delete Hall", "Are you sure you want to delete this hall?")
    if confirm:
        delete(index)
        save_halls()  # ✅ Save after delete
        refresh_listbox(hall_listbox)

def launch_admin_panel():
    load_halls()  # ✅ Load data from file when GUI starts

    global hall_listbox
    admin_win = tk.Tk()
    admin_win.title("Admin Panel - Event Hub")
    admin_win.geometry("500x400")

    tk.Label(admin_win, text="Marriage Halls", font=("Arial", 14, "bold")).pack(pady=10)

    hall_listbox = tk.Listbox(admin_win, width=60)
    hall_listbox.pack(pady=10)
    refresh_listbox(hall_listbox)

    btn_frame = tk.Frame(admin_win)
    btn_frame.pack()

    tk.Button(btn_frame, text="Add", width=12, command=add_hall_gui).grid(row=0, column=0, padx=5)
    tk.Button(btn_frame, text="Edit", width=12, command=edit_hall_gui).grid(row=0, column=1, padx=5)
    tk.Button(btn_frame, text="Delete", width=12, command=delete_hall_gui).grid(row=0, column=2, padx=5)
    tk.Button(btn_frame, text="Exit", width=12, command=admin_win.destroy).grid(row=0, column=3, padx=5)

    admin_win.mainloop()
