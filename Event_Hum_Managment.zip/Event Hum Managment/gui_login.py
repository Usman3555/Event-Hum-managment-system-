# gui_login.py

import tkinter as tk
from tkinter import messagebox
from user import User

def login():
    username = entry_username.get()
    password = entry_password.get()
    user = User.login(username, password)

    if user:
        messagebox.showinfo("Login Success", f"Logged in as {user.role}")
        root.destroy()
        if user.role == "admin":
            import gui_admin
            gui_admin.launch_admin_panel()
        else:
            import gui_user
            gui_user.launch_user_panel(user)
    else:
        messagebox.showerror("Login Failed", "Invalid username or password.")

# 🎨 GUI Window Setup
root = tk.Tk()
root.title("Event Hub - Login")
root.geometry("400x300")
root.configure(bg="#f4f4f4")

# 🔶 Header
tk.Label(root, text="Event Hub Management", font=("Helvetica", 16, "bold"), bg="#f4f4f4", fg="#333").pack(pady=20)

# 🧑 Username Field
tk.Label(root, text="Username:", bg="#f4f4f4", anchor="w").pack(fill="x", padx=50)
entry_username = tk.Entry(root, font=("Arial", 12))
entry_username.pack(fill="x", padx=50, pady=(0, 10))

# 🔑 Password Field
tk.Label(root, text="Password:", bg="#f4f4f4", anchor="w").pack(fill="x", padx=50)
entry_password = tk.Entry(root, show="*", font=("Arial", 12))
entry_password.pack(fill="x", padx=50, pady=(0, 20))

# 🔘 Login Button
login_btn = tk.Button(root, text="Login", font=("Arial", 12), bg="#5cb85c", fg="white", height=1, command=login)
login_btn.pack(pady=10, ipadx=10)

root.mainloop()
