# user.py

from hall import halls  # import hall list
from booking import Booking, save_booking

class User:
    def __init__(self, username, password, role):
        self.username = username
        self.password = password
        self.role = role

    @staticmethod
    def login(username, password):
        try:
            with open("data/users.txt", "r") as f:
                for line in f:
                    stored_username, stored_password, stored_role = line.strip().split(",")
                    if stored_username == username and stored_password == password:
                        print(f"\n✅ Login successful as {stored_role}")
                        if stored_role == "admin":
                            return Admin(username, password)
                        elif stored_role == "user":
                            return RegularUser(username, password)
            print("\n❌ Invalid credentials!")
            return None
        except FileNotFoundError:
            print("⚠️ User file not found!")
            return None


class Admin(User):
    def __init__(self, username, password):
        super().__init__(username, password, "admin")


class RegularUser(User):
    def __init__(self, username, password):
        super().__init__(username, password, "user")

    def filter_halls(self):
        print("\n📍 Enter filter details:")

        # Show all available halls before filtering
        print("\n📦 Existing Halls in System:")
        for hall in halls:
            print(f"🔹 {hall.name} | {hall.location} | Rs.{hall.price_per_head}")

        location = input("\nSearch Location (e.g., One Unit, DC, Chowk): ").strip().lower()
        max_price = int(input("Max Price Per Head: "))
        date = input("Event Date (e.g., 2025-06-10): ").strip()
        time = input("Event Time (e.g., 07:00 PM): ").strip()

        # Improved filtering: partial location match
        matched = [
            hall for hall in halls
            if location in hall.location.lower() and hall.price_per_head <= max_price
        ]

        if not matched:
            print("\n⚠️ No matching halls found.")
            return

        print("\n✅ Matching Halls:")
        for i, hall in enumerate(matched, start=1):
            print(f"{i}. {hall}")

        try:
            choice = int(input("\n👉 Enter the number of hall to book: "))
            selected_hall = matched[choice - 1]
            self.book_hall(selected_hall, date, time)
        except (IndexError, ValueError):
            print("❌ Invalid selection!")

    def book_hall(self, hall, date, time):
        print("\n📝 Booking Form")
        num_people = int(input("Number of People: "))
        total_price = hall.price_per_head * num_people

        print(f"\n💳 Total Price: Rs.{total_price}")
        confirm = input("✅ Confirm booking? (yes/no): ").lower()

        if confirm == 'yes':
            booking = Booking(self.username, hall.name, num_people, date, time, total_price)
            save_booking(booking)
            print("🎉 Booking confirmed!")
        else:
            print("❌ Booking cancelled.")
