# hall.py

import json
import os

# ✅ Shared list for all halls
halls = []

class MarriageHall:
    def __init__(self, name, location, price_per_head):
        self.name = name
        self.location = location
        self.price_per_head = price_per_head

    def to_dict(self):
        return {
            "name": self.name,
            "location": self.location,
            "price_per_head": self.price_per_head
        }

    def __str__(self):
        return f"{self.name} | {self.location} | Rs.{self.price_per_head}/head"

# ✅ Load halls from data/halls.json
def load_halls():
    global halls
    halls.clear()
    if os.path.exists("data/halls.json"):
        with open("data/halls.json", "r") as f:
            try:
                data = json.load(f)
                halls.extend([MarriageHall(**item) for item in data])
            except json.JSONDecodeError:
                print("⚠️ Error decoding halls.json")

# ✅ Save halls to data/halls.json
def save_halls():
    with open("data/halls.json", "w") as f:
        json.dump([hall.to_dict() for hall in halls], f, indent=4)

# ✅ Add hall and save
def add_hall(name, location, price_per_head):
    hall = MarriageHall(name, location, price_per_head)
    halls.append(hall)
    save_halls()

# ✅ Edit hall and save
def edit_hall(index, new_location, new_price):
    if 0 <= index < len(halls):
        halls[index].location = new_location
        halls[index].price_per_head = new_price
        save_halls()

# ✅ Delete hall and save
def delete_hall(index):
    if 0 <= index < len(halls):
        del halls[index]
        save_halls()
