from user import User
from hall import add_hall, view_halls, edit_hall, delete_hall, load_halls

def admin_menu():
    load_halls()
    while True:
        print("\n🛠️ Admin Panel:")
        print("1. Add Hall")
        print("2. View Halls")
        print("3. Edit Hall")
        print("4. Delete Hall")
        print("5. Logout")

        choice = input("👉 Select option: ")

        if choice == "1":
            name = input("Hall Name: ")
            location = input("Location: ")
            price = int(input("Price Per Head: "))
            add_hall(name, location, price)

        elif choice == "2":
            view_halls()

        elif choice == "3":
            view_halls()
            index = int(input("Enter Hall Number to Edit: ")) - 1
            new_location = input("New Location: ")
            new_price = int(input("New Price Per Head: "))
            edit_hall(index, new_location, new_price)

        elif choice == "4":
            view_halls()
            index = int(input("Enter Hall Number to Delete: ")) - 1
            delete_hall(index)

        elif choice == "5":
            print("🔒 Logging out...")
            break
        else:
            print("❌ Invalid choice.")

def main():
    print("📋 Welcome to Event Hub Management System (CLI Version)")
    username = input("👤 Username: ")
    password = input("🔑 Password: ")

    user = User.login(username, password)

    if user:
        if user.role == "admin":
            admin_menu()
        elif user.role == "user":
            user.filter_halls()

if __name__ == "__main__":
    main()
