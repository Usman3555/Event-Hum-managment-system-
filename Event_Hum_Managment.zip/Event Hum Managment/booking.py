# booking.py

import json
import os

class Booking:
    def __init__(self, username, hall_name, num_people, date, time, total_price):
        self.username = username
        self.hall_name = hall_name
        self.num_people = num_people
        self.date = date
        self.time = time
        self.total_price = total_price

    def to_dict(self):
        return {
            "username": self.username,
            "hall_name": self.hall_name,
            "num_people": self.num_people,
            "date": self.date,
            "time": self.time,
            "total_price": self.total_price
        }

def save_booking(booking):
    path = "data/bookings.json"
    bookings = []

    if os.path.exists(path):
        with open(path, "r") as f:
            try:
                bookings = json.load(f)
            except json.JSONDecodeError:
                bookings = []

    bookings.append(booking.to_dict())

    with open(path, "w") as f:
        json.dump(bookings, f, indent=4)
