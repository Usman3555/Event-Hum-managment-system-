# gui_user.py

import tkinter as tk
from tkinter import messagebox, simpledialog
from hall import load_halls, halls
from booking import Booking, save_booking

def filter_halls(location, max_price):
    location = location.lower()
    return [
        hall for hall in halls
        if location in hall.location.lower() and hall.price_per_head <= max_price
    ]

def book_hall_gui(user, hall):
    date = simpledialog.askstring("Booking", "Enter Date (e.g., 2025-06-10):")
    time = simpledialog.askstring("Booking", "Enter Time (e.g., 07:00 PM):")
    num_people = simpledialog.askinteger("Booking", "Number of People:")

    if date and time and num_people:
        total_price = hall.price_per_head * num_people
        confirm = messagebox.askyesno(
            "Confirm Booking",
            f"Hall: {hall.name}\nDate: {date}\nTime: {time}\nPeople: {num_people}\nTotal: Rs.{total_price}\n\nConfirm?"
        )
        if confirm:
            booking = Booking(user.username, hall.name, num_people, date, time, total_price)
            save_booking(booking)
            messagebox.showinfo("Success", "Booking Confirmed!")

def launch_user_panel(user):
    load_halls()  # ✅ Load from halls.json on startup

    def apply_filter():
        location = entry_location.get().strip()
        price_str = entry_price.get().strip()

        if not location or not price_str:
            messagebox.showwarning("Input Error", "Please enter both location and max price.")
            return

        try:
            max_price = int(price_str)
        except ValueError:
            messagebox.showerror("Invalid Input", "Max price must be a number.")
            return

        results = filter_halls(location, max_price)
        listbox.delete(0, tk.END)

        if not results:
            listbox.insert(tk.END, "❌ No matching halls found.")
        else:
            for hall in results:
                listbox.insert(tk.END, f"{hall.name} | {hall.location} | Rs.{hall.price_per_head}/head")
        filtered_halls.clear()
        filtered_halls.extend(results)

    def book_selected():
        selected = listbox.curselection()
        if not selected:
            messagebox.showwarning("Select Hall", "Please select a hall to book.")
            return
        hall = filtered_halls[selected[0]]
        book_hall_gui(user, hall)

    # Main GUI
    win = tk.Tk()
    win.title("User Panel - Event Hub")
    win.geometry("600x450")

    tk.Label(win, text="Search Available Halls", font=("Arial", 14, "bold")).pack(pady=10)

    frame = tk.Frame(win)
    frame.pack()

    tk.Label(frame, text="Location:").grid(row=0, column=0, padx=5)
    entry_location = tk.Entry(frame)
    entry_location.grid(row=0, column=1, padx=5)

    tk.Label(frame, text="Max Price:").grid(row=0, column=2, padx=5)
    entry_price = tk.Entry(frame)
    entry_price.grid(row=0, column=3, padx=5)

    tk.Button(frame, text="Search", command=apply_filter).grid(row=0, column=4, padx=10)

    listbox = tk.Listbox(win, width=75)
    listbox.pack(pady=15)

    tk.Button(win, text="Book Selected Hall", command=book_selected).pack(pady=5)
    tk.Button(win, text="Exit", command=win.destroy).pack(pady=5)

    filtered_halls = []  # stores matched results

    win.mainloop()
